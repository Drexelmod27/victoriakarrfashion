<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/zooming-slider/zooming-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/zooming-slider/zooming-slider-item.php';