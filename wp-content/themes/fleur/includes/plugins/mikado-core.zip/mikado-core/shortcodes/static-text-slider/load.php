<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/static-text-slider/static-text-slider.php';