<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/team-slider/team-slider.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/team-slider/team-slider-item.php';