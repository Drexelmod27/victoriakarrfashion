<div class="mkd-accordion-holder clearfix <?php echo esc_attr($acc_class) ?>">
	<?php echo fleur_mikado_remove_auto_ptag($content) ?>
</div>