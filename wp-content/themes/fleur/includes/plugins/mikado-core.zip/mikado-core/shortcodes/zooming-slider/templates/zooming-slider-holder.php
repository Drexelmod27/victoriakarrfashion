<div class="mkd-zooming-slider-holder" data-autoplay="<?php echo esc_attr($autoplay); ?>" data-slides-to-show="<?php echo esc_attr($slides_to_show); ?>" <?php fleur_mikado_inline_style($holder_margin); ?>>
	<?php echo do_shortcode($content); ?>
</div>