<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/icon/icon.php';