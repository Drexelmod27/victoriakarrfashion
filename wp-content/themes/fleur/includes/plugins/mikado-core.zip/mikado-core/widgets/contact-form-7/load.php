<?php

if( fleur_mikado_is_plugin_installed('contact-form-7') ) {
	require_once MIKADO_CORE_ABS_PATH . '/widgets/contact-form-7/contact-form-7.php';
}